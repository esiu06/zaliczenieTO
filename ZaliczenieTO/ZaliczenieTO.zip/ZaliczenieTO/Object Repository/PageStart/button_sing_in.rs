<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk zaloguj się</description>
   <name>button_sing_in</name>
   <tag></tag>
   <elementGuidId>3d2ddb1c-4352-497f-af8e-c32b40e84e57</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[class=&quot;login&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
