<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Miesiąc urodzenia</description>
   <name>select_months</name>
   <tag></tag>
   <elementGuidId>608d7cc2-eb55-4ffc-adf6-316196b0ebdd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#months > option:nth-child(5)</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
