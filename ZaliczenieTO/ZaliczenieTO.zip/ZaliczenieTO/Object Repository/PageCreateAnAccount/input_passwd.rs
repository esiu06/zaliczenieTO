<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Hasło użytkownika</description>
   <name>input_passwd</name>
   <tag></tag>
   <elementGuidId>8c041d69-14ff-4e74-919d-68f414ce61f8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;passwd&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
