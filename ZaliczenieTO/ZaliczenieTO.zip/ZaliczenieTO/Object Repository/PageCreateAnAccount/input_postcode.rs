<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Kod pocztowy</description>
   <name>input_postcode</name>
   <tag></tag>
   <elementGuidId>b96efb9c-af7d-4354-b1b7-3bb0c2ffbd92</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;postcode&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
