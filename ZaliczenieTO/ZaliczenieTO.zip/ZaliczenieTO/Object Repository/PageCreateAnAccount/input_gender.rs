<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Pole wyboru płci</description>
   <name>input_gender</name>
   <tag></tag>
   <elementGuidId>a803deba-370e-4487-9c6a-ff2318d04d09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;id_gender1&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
