<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Pole nazwisko</description>
   <name>input_lastName</name>
   <tag></tag>
   <elementGuidId>dd7b2b3f-2873-4e91-8ccb-960d94800a57</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer_lastname&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
