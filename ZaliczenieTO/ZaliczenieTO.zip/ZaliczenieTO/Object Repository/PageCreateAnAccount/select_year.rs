<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Rok urodzenia</description>
   <name>select_year</name>
   <tag></tag>
   <elementGuidId>776e8755-fd4e-4cc3-bdc2-928df17b0f11</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#years > option:nth-child(26)</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
