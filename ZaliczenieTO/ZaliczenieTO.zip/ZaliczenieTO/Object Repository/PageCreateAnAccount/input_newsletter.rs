<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Zaznaczenie do newsletter</description>
   <name>input_newsletter</name>
   <tag></tag>
   <elementGuidId>df56e1a9-7e86-4bc5-8023-2e24617d74a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;newsletter&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
