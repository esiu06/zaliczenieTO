<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Wybór dnia urodzenia</description>
   <name>select_days</name>
   <tag></tag>
   <elementGuidId>470d2493-d4ec-4068-b7c6-28e0e11d3a2d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#days > option:nth-child(7)</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
