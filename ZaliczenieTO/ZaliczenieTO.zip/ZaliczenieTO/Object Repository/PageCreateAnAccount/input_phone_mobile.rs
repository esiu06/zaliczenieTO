<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Pole Telefon komurkowy</description>
   <name>input_phone_mobile</name>
   <tag></tag>
   <elementGuidId>a45388e0-ded1-43cd-bec9-7512599e1a09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;phone_mobile&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
