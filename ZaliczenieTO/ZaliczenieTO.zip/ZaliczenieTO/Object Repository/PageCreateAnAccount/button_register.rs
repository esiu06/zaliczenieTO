<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk zarejestruj</description>
   <name>button_register</name>
   <tag></tag>
   <elementGuidId>3d42a926-7f16-442c-914c-23d86e42a780</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[id=&quot;submitAccount&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
