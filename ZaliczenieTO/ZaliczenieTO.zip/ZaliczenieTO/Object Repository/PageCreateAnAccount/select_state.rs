<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Pole Stan</description>
   <name>select_state</name>
   <tag></tag>
   <elementGuidId>a47343d0-cde2-4c5d-b4f4-c844c94bf6be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#id_state > option:nth-child(3)</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
