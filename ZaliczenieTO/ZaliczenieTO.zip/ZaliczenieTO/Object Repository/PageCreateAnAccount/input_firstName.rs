<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Pole imię</description>
   <name>input_firstName</name>
   <tag></tag>
   <elementGuidId>55da1028-4781-4ed4-a86a-e3b14cf16fd2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer_firstname&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
