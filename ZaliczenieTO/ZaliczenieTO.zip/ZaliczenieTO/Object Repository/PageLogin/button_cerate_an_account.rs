<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk utwórz konto</description>
   <name>button_cerate_an_account</name>
   <tag></tag>
   <elementGuidId>b517db83-3b52-48ea-abd8-b3c235b5ce7f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[id=&quot;SubmitCreate&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
