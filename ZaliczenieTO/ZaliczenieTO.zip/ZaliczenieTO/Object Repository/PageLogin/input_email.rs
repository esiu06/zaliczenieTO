<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Pole adresu e-mail nowego użytkownika</description>
   <name>input_email</name>
   <tag></tag>
   <elementGuidId>8cb1663c-1bc2-4bd2-9a0b-fc33b4d38bfc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;email_create&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
