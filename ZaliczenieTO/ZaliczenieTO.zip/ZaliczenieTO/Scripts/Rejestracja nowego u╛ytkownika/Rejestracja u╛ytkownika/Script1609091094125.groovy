import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

/*
 * Uruchomienie przeglądarki
 */
WebUI.openBrowser(rawUrl = GlobalVariable.url)

/*
 * Powiększenie okna przeglądarki
 */
WebUI.maximizeWindow()

/*
 * Kliknięcie przycisku zaloguj
 */
WebUI.click(findTestObject('Object Repository/PageStart/button_sing_in'))

/*
 * Wpisanie adresu użytkownika w pole adres e-mail
 */
WebUI.setText(findTestObject('Object Repository/PageLogin/input_email'), 'jankowalski2@wp.pl')

/*
 * Kliknięcie przycisku utwórz konto
 */
WebUI.click(findTestObject('Object Repository/PageLogin/button_cerate_an_account'))
/*
 * Zaznaczenie płci
 */
WebUI.click(findTestObject('Object Repository/PageCreateAnAccount/input_gender'))
/*
 * Wpisanie imienia
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_firstName'), GlobalVariable.firstName)
/*
 * Wpisanie nazwiska
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_lastName'), GlobalVariable.lastName)
/*
 * Wpisanie hasła
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_passwd'), GlobalVariable.password)
/*
 * Wybranie dnia urodzin
 */
WebUI.click(findTestObject('Object Repository/PageCreateAnAccount/select_days'))
/*
 * Wybranie miesiąca urodzin
 */
WebUI.click(findTestObject('Object Repository/PageCreateAnAccount/select_months'))
/*
 * Wybranie roku urodzin
 */
WebUI.click(findTestObject('Object Repository/PageCreateAnAccount/select_year'))
/*
 * Przystąpienie do newslettera
 */
WebUI.click(findTestObject('Object Repository/PageCreateAnAccount/input_newsletter'))
/*
 * Wpisanie imienia do formularza adresowego
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_address_firstname'), value)
/*
 * Wpisanie nazwiska do formularza adresowego
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_address_lastname'), GlobalVariable.lastName)
/*
 * Wpisanie nazwy ulicy
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_address'), GlobalVariable.address)
/*
 * Wpisanie nazwy miasta
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_city'), GlobalVariable.city)
/*
 * Wybranie stanu
 */
WebUI.click(findTestObject('Object Repository/PageCreateAnAccount/select_state'))
/*
 * Wpisanie kodu pocztowego
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_postcode'), GlobalVariable.postCode)
/*
 * Wpisanie nr telefonu komurkowego
 */
WebUI.setText(findTestObject('Object Repository/PageCreateAnAccount/input_phone_mobile'), GlobalVariable.phoneMobile)
/*
 * Kliknięcie przycisku rejestruj się
 */
WebUI.click(findTestObject('Object Repository/PageCreateAnAccount/button_register'))

