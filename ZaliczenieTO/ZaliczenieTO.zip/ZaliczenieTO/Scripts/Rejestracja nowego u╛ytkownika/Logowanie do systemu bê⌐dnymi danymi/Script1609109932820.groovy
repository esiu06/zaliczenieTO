import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

/*
 * Uruchomienie przeglądarki
 */
WebUI.openBrowser(rawUrl = GlobalVariable.url)

/*
 * Powiększenie okna przeglądarki
 */
WebUI.maximizeWindow()

/*
* Kliknięcie przycisku zaloguj
*/
WebUI.click(findTestObject('Object Repository/PageStart/button_sing_in'))

WebUI.setText(findTestObject('Object Repository/PageLogin/input_log_email'), email_error)

WebUI.setText(findTestObject('Object Repository/PageLogin/input_password'), password_error)

WebUI.click(findTestObject('Object Repository/PageLogin/button_sing_in'))
