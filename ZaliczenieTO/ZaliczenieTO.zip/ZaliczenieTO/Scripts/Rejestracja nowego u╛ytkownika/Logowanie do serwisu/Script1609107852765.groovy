import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

/*
 * Uruchomienie przeglądarki
 */
WebUI.openBrowser(rawUrl = GlobalVariable.url)

/*
 * Powiększenie okna przeglądarki
 */
WebUI.maximizeWindow()

/*
* Kliknięcie przycisku zaloguj
*/
WebUI.click(findTestObject('Object Repository/PageStart/button_sing_in'))
/*
 * Pobranie adresu email z pliku Login.xlsx
 */
WebUI.setText(findTestObject('Object Repository/PageLogin/input_log_email'), email)
/*
 * Pobranie hasła z pliku
 */
WebUI.setText(findTestObject('Object Repository/PageLogin/input_password'), password)
/*
 * Kliknięcie przycisku Zaloguj się
 */
WebUI.click(findTestObject('Object Repository/PageLogin/button_sing_in'))

