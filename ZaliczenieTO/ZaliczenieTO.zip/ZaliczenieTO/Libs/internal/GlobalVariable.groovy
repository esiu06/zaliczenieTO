package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile automationpractice.com : Adres strony automationpractice.com</p>
     */
    public static Object url
     
    /**
     * <p>Profile automationpractice.com : Imi&#281; u&#380;ytkownika</p>
     */
    public static Object firstName
     
    /**
     * <p>Profile automationpractice.com : Nazwisko u&#380;ytkownika</p>
     */
    public static Object lastName
     
    /**
     * <p>Profile automationpractice.com : Has&#322;o u&#380;ytkownika</p>
     */
    public static Object password
     
    /**
     * <p></p>
     */
    public static Object address
     
    /**
     * <p></p>
     */
    public static Object city
     
    /**
     * <p></p>
     */
    public static Object phoneMobile
     
    /**
     * <p></p>
     */
    public static Object postCode
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            url = selectedVariables['url']
            firstName = selectedVariables['firstName']
            lastName = selectedVariables['lastName']
            password = selectedVariables['password']
            address = selectedVariables['address']
            city = selectedVariables['city']
            phoneMobile = selectedVariables['phoneMobile']
            postCode = selectedVariables['postCode']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
